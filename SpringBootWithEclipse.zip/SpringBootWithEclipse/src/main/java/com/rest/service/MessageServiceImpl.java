package com.rest.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rest.dao.MessageDao;
import com.rest.models.Message;

@Service
public class MessageServiceImpl implements MessageService {

	
	@Autowired private MessageDao msgdao;
	public void display()
	{
		System.out.println("Inside MessageServiceImple");
		msgdao.display();
	}
	@Override
	public Message findById(Integer a) {
		// TODO Auto-generated method stub
		return msgdao.findById(a);
	}
}

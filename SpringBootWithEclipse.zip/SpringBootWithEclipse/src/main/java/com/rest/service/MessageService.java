package com.rest.service;

import com.rest.models.Message;

public interface MessageService {

	public void display();
	public Message findById(Integer a);
}

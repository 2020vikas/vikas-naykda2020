package com.rest.models;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;

@XmlRootElement(name="product-list")
@XmlSeeAlso({Message.class})
public class ProductList {
	private List<Message> products;
	private int size;
	
	public List<Message> getProducts() {
		return products;
	}

	public void setProducts(List<Message> products) {
		this.products = products;
		this.setSize(products.size());
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}
	
	
}

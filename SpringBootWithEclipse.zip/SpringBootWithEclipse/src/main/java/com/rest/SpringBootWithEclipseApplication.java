package com.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

/*@SpringBootApplication
public class SpringBootWithEclipseApplication {                          /// this code when we want create JAR file

	public static void main(String[] args) {
		SpringApplication.run(SpringBootWithEclipseApplication.class, args);
	}

}*/

@SpringBootApplication
public class SpringBootWithEclipseApplication extends SpringBootServletInitializer   //code for .war file creation 
{
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application)
	{
		return application.sources(SpringBootWithEclipseApplication.class);
		
	}
	public static void main(String arg[])
	{
		SpringApplication.run(SpringBootWithEclipseApplication.class, arg);
	}
}
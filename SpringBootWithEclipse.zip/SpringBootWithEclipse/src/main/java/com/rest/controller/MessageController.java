package com.rest.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.rest.models.Message;
import com.rest.service.MessageService;

@RestController
@RequestMapping(value="/message",produces="application/json")

public class MessageController {
	
	

	@Autowired 
	private MessageService dd;
	@GetMapping(value="/display")      //working
	public String getMessage(String s)
	{
		/*switch(s)
		{
		case "101":
		return "Hi In Controller of message";
		}*/
	 System.out.println("in mEssagController before dispaly");
		dd.display();
		System.out.println("in controller-----");
		return "no records found";
	}
	
	@GetMapping(value="/find",produces="application/json")
	public ResponseEntity<Message> getbyID(@RequestParam("id") Integer id)
	{
	
		System.out.println("ID in   Controller "+id);
		 Message  m=dd.findById(id);
		 System.out.println("m inside cotroller      "+m);
	   if(m==null)
	   {
		   System.out.println("Inside controller getbyID");
		 
		   return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	   }
	
	   return new ResponseEntity<Message>(m,HttpStatus.OK);
		
	}
}

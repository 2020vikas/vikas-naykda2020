package com.rest.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.rest.models.Message;

@Repository
public class MesageDaoImpl implements MessageDao
{
	
	//@Autowired private MessageDa0 msgdao;

private List<Message>lst=new LinkedList<>();

   @PostConstruct
	public void init()
	{
		/*Message m1=new Message(101,"vikas","pune");
		Message m2=new Message(201,"vinod","jalgaon");
		Message m3=new Message(301,"pinky","mumbai");
		Message m4=new Message(401,"Bali","Godri");*/
	   lst.add(new Message(101,"vikas","pune"));
		lst.add(new Message(201,"Vinod","Godri"));
		lst.add(new Message(301,"Pinky","Mumbai"));
		lst.add(new Message(401,"Bali","Jalgaon"));
	}
	@Override
	public void display() {
		// TODO Auto-generated method stub
	
		
		System.out.println("hi in MessageDaoImple");
	}

	@Override
	public Message findById(Integer a) {
		// TODO Auto-generated method stub
		
		
		Iterator<Message>itr=lst.iterator();
		
		while(itr.hasNext())
		{
		  Message dd=(Message)itr.next();
		  System.out.println("iterer   "+dd.getId());
		  
		  if(dd.getId()==a)
			{
				System.out.println("a     "+a);
				return dd;
			}
		}
		/*for(Message m:lst)
		{
			
			System.out.println("================================inside daoImplement==============================="+a+"   m  "+m.getId());
			if(m.getId()==a)
			{
				System.out.println("a     "+a);
				return m;
			}
				
		}*/
		return null;
	}

}

package com.rest.dao;

import com.rest.models.Message;

public interface MessageDao {

	public void display();
	public Message findById(Integer a);
}
